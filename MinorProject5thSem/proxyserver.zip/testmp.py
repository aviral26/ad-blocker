from bs4 import BeautifulSoup
from numpy import *
import re, math
import sys


adstr = """
<a href="http://main.exoclick.com/click.php?data=YWRleHBydHw0MDUyMjR8MHxodHRwJTNBJTJGJTJGbXBkb3Ryay5jb20lMkZtdCUyRnYyMjQ0Mzg0YTR3MjMzeTI5NHcyMDMlMkYlMjZzdWJpZDElM0QlN0Jjb252ZXJzaW9uc190cmFja2luZyU3RHwxOTUwODV8fHw2NXwxMzgyOTAyMzA0fHRoZXBpcmF0ZWJheS5zeHwxMjAuNTYuMjI3LjIyMHw0MDUyMjQtNjkwOTM5N3w2OTA5Mzk3fDUyMjYwNXw0NzJ8NHw1NGQzMmE4MjZmYWQzZjZhMzhkZTA4ZTAzMmNkYWJlYg%3D%3D" target="_blank">
<img border="0" height="90" src="http://static.exoclick.com/banners/197004/1-728x90_1.jpg" width="728"/></a>"""

# totalhtml = """HTTP/1.1 200 OK
# Server: nginx
# Date: Sun, 27 Oct 2013 19:31:44 GMT
# Content-Type: text/html; charset=utf-8
# Transfer-Encoding: chunked
# Connection: close
# Vary: Accept-Encoding
# Expires: Mon, 26 Jul 1997 05:00:00 GMT
# Cache-Control: no-cache, must-revalidate
# Pragma: no-cache
# P3P: CP="IDC DSP COR ADM DEVi TAIi PSA PSD IVAi IVDi CONi HIS OUR IND CNT"
# Set-Cookie: impressions=x%9C%8D%CE9%0A%C30%14%04%D0%BB%E8%04%7FS%FC%97%D3%A8%08X%10WRgt%F7%C8%EE%02N%E2rf%E01%C5%C5%F7%EA%02%99H%A28%FB%DEf%95%D6%DA%5B%8A%EA%1Cg%ECu%7B%1E%11Y%C9%00Ud%F6%EA%E9UZ%FF%DC%88Ab%9C%22%DA%7D%D1%10%FE%8A%88%8F%9C%2FD%BC%12%09%F4%FB%C7c%9B%22%9Bi%5En%8B%0C%F4%E3%23%C5%18o8%5C%5C%11; expires=Mon, 28-Oct-2013 19:31:44 GMT; path=/; domain=.exoclick.com

# 254
# <html><body style="margin: 0px; background-color: #FFFFFF; font-family: Verdana, Arial">
# <a href="http://main.exoclick.com/click.php?data=YWRleHBydHw0MDUyMjR8MHxodHRwJTNBJTJGJTJGbXBkb3Ryay5jb20lMkZtdCUyRnYyMjQ0Mzg0YTR3MjMzeTI5NHcyMDMlMkYlMjZzdWJpZDElM0QlN0Jjb252ZXJzaW9uc190cmFja2luZyU3RHwxOTUwODV8fHw2NXwxMzgyOTAyMzA0fHRoZXBpcmF0ZWJheS5zeHwxMjAuNTYuMjI3LjIyMHw0MDUyMjQtNjkwOTM5N3w2OTA5Mzk3fDUyMjYwNXw0NzJ8NHw1NGQzMmE4MjZmYWQzZjZhMzhkZTA4ZTAzMmNkYWJlYg%3D%3D" target="_blank">
# <img width="728" height="90" src="http://static.exoclick.com/banners/197004/1-728x90_1.jpg" border="0"></a></body></html>
# asdasdas
# <a class="external photoLink _8o _8t lfloat" aria-hidden="true" href="https://www.facebook.com/trishala.choudhary.1?ref=nf" data-ft="{&quot;type&quot;:41,&quot;tn&quot;:&quot;E&quot;}" tabindex="-1"><img class="img" src="https://fbcdn-profile-a.akamaihd.net/hprofile-ak-ash1/372659_1592523332_382752397_s.jpg" alt=""></a>
# """

# imgs = re.findall(r'<a.*?</a>', totalhtml, re.DOTALL)
# print imgs
# sys.exit(0)



string = """<a href="http://r.turn.com/r/tpclick/id/0ywXn7rpvnU9zwUA2AcBAA/3c/http://adclick.g.doubleclick.net/aclk?sa=l&amp;ai=CtCOXZuZjUqSYOcSDmwX41oCoBuiX-IkCiKf8qkTAjbcBEAEgAFCAx-HEBGDlwuSDpA6CARdjYS1wdWItMzQ5NjI2MjkzMTUxNTMxMaABjPe59APIAQmoAwGqBElP0O6vQODLQgu4cRk8n6W8chi_byCZpqg_xalOQcqlrqnQ_p6BS2pgscu5kEPNQJuoraLiRuiUkuOQZzELRfcZuPwCnIKJAI-mgAaOq4nEwqP36RKgBiE&amp;num=1&amp;sig=AOD64_2PErzZLIIvKQbwI9RvuGxKvcFCFg&amp;client=ca-pub-3496262931515311&amp;adurl=/url/http://click.solocpm.com/a.aspx?Task=Click&amp;ZoneID=36968&amp;CampaignID=38396&amp;AdvertiserID=5&amp;BannerID=45809&amp;SiteID=1&amp;RandomNumber=1623607448&amp;Keywords=" target="_blank"><img alt="Flat 50% Off on Women Footware" border="0" height="60" src="http://jaymailer.com/Mailers/img/Women_Footware_468x60.jpg" width="468"/></a>"""

#string = """ <a href='www.conweets/index' style='text-decoration:none;'> <img src='http://conweets/images/logo2.png' width='160' /></a>"""
# string = """<a class="external photoLink _8o _8t lfloat" aria-hidden="true" href="https://www.facebook.com/trishala.choudhary.1?ref=nf" data-ft="{&quot;type&quot;:41,&quot;tn&quot;:&quot;E&quot;}" tabindex="-1"><img class="img" src="https://fbcdn-profile-a.akamaihd.net/hprofile-ak-ash1/372659_1592523332_382752397_s.jpg" alt=""></a>"""

# string = """<a href='www.conweets/index' style='text-decoration:none;'> <img src='http://conweets.com/images/logo2.png' width='160' /></a>"""

# string = """<a href="http://pubads.g.doubleclick.net/gampad/clk?id=56438697&iu=/6444/espn.cricinfo.nondartserved/clicktracker" target="_blank"><img src="http://i.imgci.com/homepage/india/Adidas_Nov18th_125x125.gif" width="125" height="125" border="0" alt="Adidas" title="Adidas" /></a> """
soup = BeautifulSoup(string)
# soup2 = BeautifulSoup(string2)
features = arange(1559, dtype=float)**0
theta = arange(1559, dtype=float)**0

img = soup.img
imgAttrs = img.attrs

a = soup.a
anchorAttrs = a.attrs

features[0] = 1

if 'height' in imgAttrs:
    features[1] = (int(imgAttrs['height']) - 46.391) / 54.767
else:
    features[1] = 0

if 'width' in imgAttrs:
    features[2] = (int(imgAttrs['width']) - 112.66) / 130.66
else:
    features[2] = 0

if 'width' in imgAttrs and 'height' in imgAttrs:
    features[3] = (int(imgAttrs['width']) / int(imgAttrs['height']) - 2.8263) / 5.4267
else:
    features[3] = 0

features[4] = 0

if 'alt' in imgAttrs:
    alt = imgAttrs['alt'].lower()
else:
    alt = ""

caption = soup.a.text.lower()
url = imgAttrs['src'].lower()
ancurl = anchorAttrs['href'].lower()
origurl = "www.conweets.com"

replaceArr = [("http://", ""), ("https://", "")]

for t in replaceArr:
    url = url.replace(t[0], t[1])
    ancurl = ancurl.replace(t[0], t[1])
    origurl = origurl.replace(t[0], t[1])

replaceCharsArr = [(" ", "+"), ("/", "+"), ("&amp;", "+"), ("&", "+"), (".", "+"), ("/", "+"), ("=", "+")]

urlPlus = url
ancurlPlus = ancurl
origurlPlus = origurl
altPlus = alt
captionPlus = caption

toReplaceArr = [urlPlus, ancurlPlus, origurlPlus, altPlus, captionPlus]

print toReplaceArr

for t in replaceCharsArr:
    for s in toReplaceArr:
        s = s.replace(t[0], t[1])
        s = re.sub(r'(\++)', r'+', s)

urlPlus = toReplaceArr[0]
ancurlPlus = toReplaceArr[1]
origurlPlus = toReplaceArr[2]
altPlus = toReplaceArr[3]
captionPlus = toReplaceArr[4]

c = 4

with open("ad.names.txt") as f:
    for line in f:
        l = line.replace("\n", "")
        ftrs = l.split("*")
        ftr = ftrs[0]
        kw = ftrs[1]

        if ftr == 'url':
            a = url
            b = urlPlus
        elif ftr == 'origurl':
            a = origurl
            b = origurlPlus
        elif ftr == 'ancurl':
            a = ancurl
            b = ancurlPlus
        elif ftr == 'alt':
            a = alt
            b = altPlus
        elif ftr == 'caption':
            a = caption
            b = captionPlus

        if a.find(kw) > -1 or b.find(kw) > -1:
            print kw, "\n"
            features[c] = 1
        else:
            features[c] = 0

        c = c + 1

c = 0
print theta.dtype

rang = 1
with open("theta.txt") as f:
	for line in f:
		l = line.replace("\n", "")
		l = l.replace("\r", "")
		l = l.replace(" ", "")
		#print rang
		if rang > 5 and rang < 1565:
			theta[c] = float(l)
			c = c + 1
		rang = rang + 1

features = asmatrix(features)
theta = asmatrix(theta).T
print features
print theta
hypothesis = float(features*theta)
result = 1 / (1 + math.exp(-1*hypothesis))
print result
print hypothesis
