# -*- coding: cp1252 -*-
# <PythonProxy.py>
#
#Copyright (c) <2009> <Fábio Domingues - fnds3000 in gmail.com>
#
#Permission is hereby granted, free of charge, to any person
#obtaining a copy of this software and associated documentation
#files (the "Software"), to deal in the Software without
#restriction, including without limitation the rights to use,
#copy, modify, merge, publish, distribute, sublicense, and/or sell
#copies of the Software, and to permit persons to whom the
#Software is furnished to do so, subject to the following
#conditions:
#
#The above copyright notice and this permission notice shall be
#included in all copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
#EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
#OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
#NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
#HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
#WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
#FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
#OTHER DEALINGS IN THE SOFTWARE.

"""\
Copyright (c) <2009> <Fábio Domingues - fnds3000 in gmail.com> <MIT Licence>

                  **************************************
                 *** Python Proxy - A Fast HTTP proxy ***
                  **************************************

Neste momento este proxy é um Elie Proxy.

Suporta os métodos HTTP:
 - OPTIONS;
 - GET;
 - HEAD;
 - POST;
 - PUT;
 - DELETE;
 - TRACE;
 - CONENCT.

Suporta:
 - Conexões dos cliente em IPv4 ou IPv6;
 - Conexões ao alvo em IPv4 e IPv6;
 - Conexões todo o tipo de transmissão de dados TCP (CONNECT tunneling),
     p.e. ligações SSL, como é o caso do HTTPS.

A fazer:
 - Verificar se o input vindo do cliente está correcto;
   - Enviar os devidos HTTP erros se não, ou simplesmente quebrar a ligação;
 - Criar um gestor de erros;
 - Criar ficheiro log de erros;
 - Colocar excepções nos sítios onde é previsível a ocorrência de erros,
     p.e.sockets e ficheiros;
 - Rever tudo e melhorar a estrutura do programar e colocar nomes adequados nas
     variáveis e métodos;
 - Comentar o programa decentemente;
 - Doc Strings.

Funcionalidades futuras:
 - Adiconar a funcionalidade de proxy anónimo e transparente;
 - Suportar FTP?.


(!) Atenção o que se segue só tem efeito em conexões não CONNECT, para estas o
 proxy é sempre Elite.

Qual a diferença entre um proxy Elite, Anónimo e Transparente?
 - Um proxy elite é totalmente anónimo, o servidor que o recebe não consegue ter
     conhecimento da existência do proxy e não recebe o endereço IP do cliente;
 - Quando é usado um proxy anónimo o servidor sabe que o cliente está a usar um
     proxy mas não sabe o endereço IP do cliente;
     É enviado o cabeçalho HTTP "Proxy-agent".
 - Um proxy transparente fornece ao servidor o IP do cliente e um informação que
     se está a usar um proxy.
     São enviados os cabeçalhos HTTP "Proxy-agent" e "HTTP_X_FORWARDED_FOR".

"""
from bs4 import BeautifulSoup
from numpy import *
import re, math
import sys
import socket, thread, select


__version__ = '0.1.0 Draft 1'
BUFLEN = 8192
VERSION = 'Python Proxy/'+__version__
HTTPVER = 'HTTP/1.1'

class ConnectionHandler:
    def __init__(self, connection, address, timeout):
        self.client = connection
        self.client_buffer = ''
        self.timeout = timeout
        self.html = ''
        self.ahrefs = []
        self.adnames = []
        self.theta = []
        self.fileread = 0
        self.method, self.path, self.protocol = self.get_base_header()
        if self.method=='CONNECT':
            self.method_CONNECT()
        elif self.method in ('OPTIONS', 'GET', 'HEAD', 'POST', 'PUT',
                             'DELETE', 'TRACE'):
            self.method_others()
        self.client.close()
        self.target.close()

    def get_base_header(self):
        while 1:
            self.client_buffer += self.client.recv(BUFLEN)
            end = self.client_buffer.find('\n')
            if end!=-1:
                break
        print '%s'%self.client_buffer[:end]#debug
        data = (self.client_buffer[:end+1]).split()
        self.client_buffer = self.client_buffer[end+1:]
        return data

    def method_CONNECT(self):
        self._connect_target(self.path)
        self.client.send(HTTPVER+' 200 Connection established\n'+
                         'Proxy-agent: %s\n\n'%VERSION)
        self.client_buffer = ''
        self._read_write()

    def method_others(self):
        self.path = self.path[7:]
        i = self.path.find('/')
        host = self.path[:i]
        path = self.path[i:]
        self._connect_target(host)
        self.client_buffer = self.client_buffer.replace("gzip,deflate,", "")
        self.client_buffer = self.client_buffer.replace("gzip,deflate", "")
        self.target.send('%s %s %s\n'%(self.method, path, self.protocol)+
                         self.client_buffer)
        self.client_buffer = ''
        self._read_write()

    def _connect_target(self, host):
        i = host.find(':')
        if i!=-1:
            port = int(host[i+1:])
            host = host[:i]
        else:
            port = 80
        (soc_family, _, _, _, address) = socket.getaddrinfo(host, port)[0]
        self.target = socket.socket(soc_family)
        self.target.connect(address)

    def _read_write(self):
        time_out_max = self.timeout/3
        socs = [self.client, self.target]
        count = 0
        while 1:
            count += 1
            (recv, _, error) = select.select(socs, [], socs, 3)
            if error:
                break
            if recv:
                for in_ in recv:
                    data = in_.recv(BUFLEN)
                    if in_ is self.client:
                        out = self.target
                    else:
                        out = self.client
                    if data:
                        if out is self.client:
                            data = self.processHTML(data)
                            # data = data.replace("Mac", "Ma ")
                        out.send(data)
                        count = 0
            if count == time_out_max:
                break

    def processHTML(self, data):
        imgs = re.findall(r'<a\s.*?</a>', data, re.DOTALL)

        for candidate in imgs:
            if candidate.find('<img') > -1 and self.adOrNot(candidate):
                print "\n\n*************AD REPLACE*****************************\n\n"
                print candidate
                print "\n\n*************AD REPLACE*****************************\n\n"

                # print "\n\n*************DATA BEFORE REPLACE*****************************\n\n"
                # print data
                # print "\n\n*************END OF DATA BEFORE REPLACE*****************************\n\n"

                #tocandidate = re.sub(r'src\s*=\s*(\'|\")(.*?)(\'|\")', r'src="http://www.conweets.com/images/logo2.png"', candidate)
                repString = " " * (len(candidate)-11)
                data = data.replace(candidate, "<h1>AD</h1>" + repString)

                # print "\n\n*************DATA AFTER REPLACE*****************************\n\n"
                # print data
                # print "\n\n*************END OF DATA AFTER REPLACE*****************************\n\n"


        return data

    def adOrNot(self, adstring):

        # string = """<a href="http://r.turn.com/r/tpclick/id/0ywXn7rpvnU9zwUA2AcBAA/3c/http://adclick.g.doubleclick.net/aclk?sa=l&amp;ai=CtCOXZuZjUqSYOcSDmwX41oCoBuiX-IkCiKf8qkTAjbcBEAEgAFCAx-HEBGDlwuSDpA6CARdjYS1wdWItMzQ5NjI2MjkzMTUxNTMxMaABjPe59APIAQmoAwGqBElP0O6vQODLQgu4cRk8n6W8chi_byCZpqg_xalOQcqlrqnQ_p6BS2pgscu5kEPNQJuoraLiRuiUkuOQZzELRfcZuPwCnIKJAI-mgAaOq4nEwqP36RKgBiE&amp;num=1&amp;sig=AOD64_2PErzZLIIvKQbwI9RvuGxKvcFCFg&amp;client=ca-pub-3496262931515311&amp;adurl=/url/http://click.solocpm.com/a.aspx?Task=Click&amp;ZoneID=36968&amp;CampaignID=38396&amp;AdvertiserID=5&amp;BannerID=45809&amp;SiteID=1&amp;RandomNumber=1623607448&amp;Keywords=" target="_blank"><img alt="Flat 50% Off on Women Footware" border="0" height="60" src="http://jaymailer.com/Mailers/img/Women_Footware_468x60.jpg" width="468"/></a>"""
        # string = """ <a href='www.conweets/index' style='text-decoration:none;'> <img src='http://conweets/images/logo2.png' width='160' /></a>"""
        # string = """<a class="external photoLink _8o _8t lfloat" aria-hidden="true" href="https://www.facebook.com/trishala.choudhary.1?ref=nf" data-ft="{&quot;type&quot;:41,&quot;tn&quot;:&quot;E&quot;}" tabindex="-1"><img class="img" src="https://fbcdn-profile-a.akamaihd.net/hprofile-ak-ash1/372659_1592523332_382752397_s.jpg" alt=""></a>"""
        soup_ad = BeautifulSoup(adstring)
        print soup_ad
        features = arange(1559, dtype=float)**0
        theta = arange(1559, dtype=float)**0

        img = soup_ad.img
        imgAttrs = img.attrs

        a = soup_ad.a
        anchorAttrs = a.attrs

        features[0] = 1

        if 'height' in imgAttrs:
            imgAttrs['height'] = re.sub(r'[^0-9]+', "", imgAttrs['height'])

        if 'width' in imgAttrs:
            imgAttrs['width'] = re.sub(r'[^0-9]+', "", imgAttrs['width'])

        if 'height' in imgAttrs:
            features[1] = (int(imgAttrs['height']) - 46.391) / 54.767
        else:
            features[1] = 0

        if 'width' in imgAttrs:
            features[2] = (int(imgAttrs['width']) - 112.66) / 130.66
        else:
            features[2] = 0

        if 'width' in imgAttrs and 'height' in imgAttrs:
            features[3] = (int(imgAttrs['width']) / int(imgAttrs['height']) - 2.8263) / 5.4267
        else:
            features[3] = 0

        features[4] = 0

        if 'alt' in imgAttrs:
            alt = imgAttrs['alt'].lower()
        else:
            alt = ""

        caption = soup_ad.a.text.lower()

        if 'src' in imgAttrs:
            url = imgAttrs['src'].lower()
        else:
            url = ""

        if 'href' in anchorAttrs:
            ancurl = anchorAttrs['href'].lower()
        else:
            ancurl = ""

        origurl = "www.conweets.com"

        replaceArr = [("http://", ""), ("https://", "")]

        for t in replaceArr:
            url = url.replace(t[0], t[1])
            ancurl = ancurl.replace(t[0], t[1])
            origurl = origurl.replace(t[0], t[1])

        replaceCharsArr = [(" ", "+"), ("/", "+"), ("&amp;", "+"), ("&", "+"), (".", "+"), ("/", "+"), ("=", "+")]

        urlPlus = url
        ancurlPlus = ancurl
        origurlPlus = origurl
        altPlus = alt
        captionPlus = caption

        toReplaceArr = [urlPlus, ancurlPlus, origurlPlus, altPlus, captionPlus]

        for t in replaceCharsArr:
            for s in toReplaceArr:
                s = s.replace(t[0], t[1])
                s = re.sub(r'(\++)', r'+', s)

        urlPlus = toReplaceArr[0]
        ancurlPlus = toReplaceArr[1]
        origurlPlus = toReplaceArr[2]
        altPlus = toReplaceArr[3]
        captionPlus = toReplaceArr[4]

        c = 4

        if self.fileread == 0:
            with open("ad.names.txt") as f:
                for line in f:
                    self.adnames.append(line);
            with open("theta.txt") as f:
                for line in f:
                    self.theta.append(line)
            self.fileread = 1

        for line in self.adnames:
            l = line.replace("\n", "")
            ftrs = l.split("*")
            ftr = ftrs[0]
            kw = ftrs[1]

            if ftr == 'url':
                a = url
                b = urlPlus
            elif ftr == 'origurl':
                a = origurl
                b = origurlPlus
            elif ftr == 'ancurl':
                a = ancurl
                b = ancurlPlus
            elif ftr == 'alt':
                a = alt
                b = altPlus
            elif ftr == 'caption':
                a = caption
                b = captionPlus

            if a.find(kw) > -1 or b.find(kw) > -1:
                features[c] = 1
            else:
                features[c] = 0

            c = c + 1

        c = 0

        rang = 1
        for line in self.theta:
            l = line.replace("\n", "")
            l = l.replace("\r", "")
            l = l.replace(" ", "")
            #print rang
            if rang > 5 and rang < 1565:
                theta[c] = float(l)
                c = c + 1
            rang = rang + 1

        features = asmatrix(features)
        theta = asmatrix(theta).T
        hypothesis = float(features*theta)
        result = 1 / (1 + math.exp(-1*hypothesis))

        print "----------- \n Result for \n", adstring, "\n", result, "\n-----------------------"
        if result >= 0.35:
            return 1
        else:
            return 0

def start_server(host='localhost', port=8080, IPv6=False, timeout=60,
                  handler=ConnectionHandler):
    if IPv6==True:
        soc_type=socket.AF_INET6
    else:
        soc_type=socket.AF_INET
    soc = socket.socket(soc_type)
    soc.bind((socket.gethostname(), port))
    # soc.bind((host, port))
    print "Serving on %s:%d."%(host, port)#debug
    soc.listen(0)
    while 1:
        thread.start_new_thread(handler, soc.accept()+(timeout,))

if __name__ == '__main__':
    start_server()